import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const root=path.dirname(fileURLToPath(import.meta.url));
export function locations(home=os.homedir(),platform=process.platform,appdata=process.env.APPDATA){
 if(!['win32','darwin'].includes(platform)) throw new Error('Suportado somente em Windows e macOS.');
 return {destination:path.join(home,'EditaIAPro','PremiereMCP-1.1.0'),
 panel:path.join(platform==='win32'?(appdata||path.join(home,'AppData','Roaming')):path.join(home,'Library','Application Support'),'Adobe','CEP','extensions','com.mcp.premiere.cepbridge'),
 temp:path.join(os.tmpdir(),'premiere-mcp-bridge')};
}
export async function verify(base=root){
 const manifest=JSON.parse(await fs.readFile(path.join(base,'integrity.json'),'utf8'));
 for(const [name,hash] of Object.entries(manifest)){
  const actual=createHash('sha256').update(await fs.readFile(path.join(base,...name.split('/')))).digest('hex');
  if(actual!==hash) throw new Error('Arquivo alterado: '+name);
 }
 return Object.keys(manifest).length;
}
async function exists(p){try{await fs.access(p);return true;}catch{return false;}}
async function main(){
 const args=process.argv.slice(2);
 if(args.some(a=>!['--help','--check','--install'].includes(a))) throw new Error('Opção desconhecida. Use --help.');
 if(!args.length||args.includes('--help')){console.log('Edita IA Pro — Premiere MCP 1.1.0\nnode install.mjs --check: confere integridade\nnode install.mjs --install: copia runtime e painel; não altera clientes nem modo de desenvolvedor do Adobe.\nLeia LEIA-PRIMEIRO.txt antes de instalar.');return;}
 if(Number(process.versions.node.split('.')[0])<20) throw new Error('Instale Node.js 20 ou superior.');
 console.log('Arquivos verificados: '+await verify());
 if(!args.includes('--install'))return;
 const p=locations();
 if(await exists(p.destination)||await exists(p.panel)) throw new Error('Destino ou painel já existe. Instalação interrompida para preservar a configuração anterior.');
 await fs.mkdir(path.dirname(p.destination),{recursive:true});
 await fs.cp(path.join(root,'runtime'),path.join(p.destination,'runtime'),{recursive:true,errorOnExist:true,force:false});
 await fs.mkdir(path.dirname(p.panel),{recursive:true});
 await fs.cp(path.join(root,'runtime','node_modules','adobe-premiere-pro-mcp','cep-plugin'),p.panel,{recursive:true,errorOnExist:true,force:false});
 await fs.mkdir(p.temp,{recursive:true});
 const config={mcpServers:{premiere_pro_edita_ia_pro:{command:process.execPath,args:[path.join(p.destination,'runtime','node_modules','adobe-premiere-pro-mcp','dist','index.js')],env:{PREMIERE_TEMP_DIR:p.temp,PREMIERE_MCP_TELEMETRY:'0',PREMIERE_MCP_UPDATE_CHECK:'0'}}}};
 const configPath=path.join(p.destination,'configuracao-mcp.json');
 await fs.writeFile(configPath,JSON.stringify(config,null,2));
 console.log('Cópia concluída. Configuração para importar manualmente: '+configPath+'\nDiretório da ponte: '+p.temp+'\nO painel CEP original não tem assinatura. A abertura depende da configuração de desenvolvimento do Adobe; consulte o guia. A conexão ainda deve ser testada.');
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(e=>{console.error(e.message);process.exitCode=1;});
