---
name: edita-ia-pro
description: Orientar projetos do kit Edita IA Pro de edição com IA, escolhendo entre artes para Premiere, DaVinci ou CapCut, edição nativa conectada e vídeo completo com HyperFrames. Usar no início de um projeto do curso ou quando o aluno mudar o destino da entrega.
---

# Edita IA Pro — edição com IA

## Começar pela entrega

Reaproveite o que o aluno já disse. Se ainda não houver destino, pergunte: “Você quer continuar no Premiere, DaVinci ou CapCut, ou prefere que eu monte e entregue o vídeo pronto?” Se houver editor escolhido, esclareça apenas quando necessário: artes para importar, montagem no editor ou ambos. Não repita essa entrevista a cada alteração.

Pergunte versão e plataforma do editor quando isso afetar formato ou integração. Diferencie CapCut desktop, mobile e web. Confirme proporção, resolução, fps, trecho e referência somente se estiverem ausentes e forem necessários. Para uma arte isolada, não exija transcrição de todo o vídeo.

Leia [entregas.md](references/entregas.md) para definir formato e verificação. Registre as escolhas no BRIEF.md do projeto, com destino, entrega, editabilidade, formatos, mídia-fonte, intervalo e recursos disponíveis. Crie o arquivo somente dentro do projeto autorizado.

## Escolher ferramentas conforme o destino

- Artes para editor: use HyperFrames para animação e render; entregue elementos separados e um mapa de entrada/saída. Preserve o código-fonte para revisões. Não substitua a montagem existente por um MP4 completo sem solicitação.
- Editor conectado: verifique ferramentas realmente disponíveis e faça uma leitura do projeto antes de prometer edição direta. HyperFrames não instala nem substitui a ponte do Premiere, a integração do Resolve ou uma integração do CapCut. Preserve a sequência original ao criar uma versão nova.
- Vídeo pronto: use o motor HyperFrames local para compor e renderizar, com prévia e revisão do arquivo exportado. O aluno pode orientar pela conversa e revisar no Studio sem operar um editor tradicional.
- “Direto no GPT”: explique qual ambiente está sendo usado. Uma conversa comum não ganha acesso ao computador ou um renderizador só por anexar esta skill. Verifique arquivos, execução e ferramentas disponíveis. Quando necessário, encaminhe ao Codex local ou a um ambiente de execução preparado; não prometa instalação local a partir de um chat sem ferramentas.

No kit instalado, carregue somente as skills necessárias: edit-video para montagem completa; cut-silences e cut-mistakes para limpeza; short-form-edit para shorts; video-storytelling para narrativa; hyperframes-video-beats e style-library para artes; hyperframes, gsap e hyperframes-cli para composição e exportação. Se o kit não estiver no projeto atual, localize sua pasta e leia o AGENTS.md dela; não presuma que as skills auxiliares estão instaladas globalmente.

## Decupagem em editor conectado

Quando o pedido for limpar, decupar ou selecionar takes dentro do Premiere, DaVinci ou CapCut, leia `docs/DECUPAGEM-SEGURA.md` na raiz do kit antes de agir. Trate instalação e edição como tarefas separadas: se a conversa atual contiver instalação de dependências, descoberta ampla de ferramentas, logs extensos ou o teste inicial do kit, não comece a decupagem nela. Prepare um resumo curto com os caminhos e o estado confirmado e peça que o aluno abra uma nova tarefa no mesmo projeto. Não repita perguntas já respondidas no resumo.

Na tarefa limpa, use somente a integração do editor necessária. Reaproveite uma transcrição existente; caso falte, confirme o idioma antes de gerar uma única transcrição com tempos. Planeje todos os cortes antes de alterar a timeline e preserve a sequência original numa duplicata.

Use por padrão o **modo econômico**: aplique o plano completo em lote ou no menor número de lotes que a integração aceitar. Só use o **modo demonstração visual** quando o usuário pedir explicitamente para acompanhar os cortes acontecendo. Antes de executar, avise em linguagem simples e humana, sem jargão e sem pedir uma nova confirmação: **“Beleza, vou fazer no modo demonstração visual para você acompanhar os cortes acontecendo. Só para você saber: isso costuma levar mais tempo e gastar mais créditos do que aplicar tudo de uma vez, porque o editor executa cada corte separadamente. Como você pediu esse modo, vou seguir assim.”**

No modo demonstração visual, feche a lista completa uma única vez e depois execute os itens em ordem, um por um, para que a timeline mostre a progressão. Reutilize o mesmo plano; não reanalise, não retranscreva e não faça uma nova consulta ao modelo entre cortes. Envie ao editor somente o comando e receba somente o resultado compacto de cada item. Não acrescente pausas artificiais longas. Se o editor agrupar a atualização visual, informe essa limitação e use poucos blocos verificáveis.

Não faça uma nova chamada de modelo para decidir cada clipe. Prefira o MCP do editor ao controle visual; use a interface somente para uma operação que a integração não exponha. O limite de repetição vale para a mesma ação pelo mesmo método, não para o objetivo da edição. Uma dificuldade não encerra a tarefa: verifique o estado, troque de método e continue quando houver um caminho seguro.

Considere respostas como `There has been no change` falta de evidência visual, não prova automática de falha. Depois da primeira resposta, faça uma verificação independente do estado. Se a ação for segura e idempotente, permita uma segunda tentativa do mesmo método. Se continuar sem evidência, não repita o mesmo clique, espera ou consulta; use um comando estruturado do MCP, outra inspeção ou outro caminho seguro. Só peça intervenção do usuário quando os caminhos disponíveis falharem, o estado ficar incerto ou prosseguir puder duplicar cortes, apagar material ou corromper o projeto. Esperas de uma operação longa com progresso confirmado seguem o tempo limite da própria operação e não contam como tentativas iguais.

Se o arquivo do projeto estiver numa pasta sincronizada, como Google Drive, OneDrive ou Dropbox, não atribua automaticamente qualquer falha ao serviço. Antes de editar, recomende trabalhar com uma cópia local do arquivo de projeto e preservar o original; as mídias podem permanecer vinculadas quando o editor suportar isso. Sincronize ou copie a nova versão somente depois de salvar e fechar o editor. Essa precaução reduz conflitos de versão e avisos de alteração externa, mas não substitui o limite de tentativas nem justifica repetir operações visuais.

Mantenha resultados de ferramentas compactos: peça IDs, timecodes, estado da sequência e erros relevantes. Não liste catálogos completos de ferramentas, esquemas de conectores, árvores de acessibilidade ou bibliotecas de animação durante uma decupagem. Animações e referências entram numa etapa posterior, quando forem solicitadas. Não altere modelo, nível de raciocínio ou velocidade sem escolha do usuário.

## Direção e revisão

Antes de impor um template a quem já edita, identifique seu método. Ofereça usar o padrão do kit ou adaptar a um projeto próprio. MP4 mostra aparência e ritmo; projeto nativo com mídias e dependências permite investigar efeitos, organização, keyframes e curvas. Para estudar ambos, prefira o render final acompanhado de uma cópia coletada do projeto e do trecho/sequence relevante. Não afirme que um efeito específico foi usado com base apenas no MP4.

O kit distribuído ensina a descobrir o método de cada aluno; não contém o perfil pessoal de Edita IA Pro como padrão. Após analisar exemplos, mostre à pessoa um resumo curto do que entendeu, citando projeto, sequência e timecode quando observados. Diferencie declarações da pessoa, parâmetros realmente inspecionados e inferências. Um padrão observado numa edição pode ser uma escolha daquele trabalho, não uma preferência permanente.

Antes de transformar observações em preferência para trabalhos futuros, pergunte: “Entendi que você prefere [método], com base em [exemplos]. Quer que eu priorize isso nos próximos projetos, use só neste trabalho ou ajuste alguma coisa?” Aguarde a resposta. Se a pessoa já pediu explicitamente que uma preferência seja sempre usada, não peça a mesma confirmação novamente. Sem confirmação, mantenha apenas observações do projeto atual, identificadas como não aprovadas para uso futuro.

Registre somente preferências aprovadas no PERFIL-DE-EDICAO.md do aluno, separado das regras compartilhadas do curso, indicando escopo e origem da aprovação. O perfil permanece privado e não integra o pacote distribuído aos demais alunos. Para utilizá-lo em outros projetos, configure uma localização pessoal acessível à instalação do aluno; não prometa memória automática entre conversas sem esse mecanismo. Permita revisar, substituir ou remover preferências e respeite a direção específica de cada novo trabalho.

Pergunte somente o necessário sobre editabilidade, efeitos preferidos, suavização, motion blur, organização e plugins permitidos. Inspecione uma amostra antes de produzir em lote. Respeite o método escolhido; se uma alternativa mudar como a pessoa poderá editar o resultado, apresente o motivo e uma comparação curta preservando o original, e peça sua escolha antes de substituir o método. Não prometa ler curvas ou parâmetros que a integração não expõe: use uma inspeção suportada ou identifique a limitação.

Quando a entrega for nativa, construa com os efeitos e controles do editor escolhido. Quando for render HyperFrames, explique que a aparência pode ser reproduzida, mas os controles de edição permanecem no projeto HyperFrames. Use templates como ponto de partida ajustável, não como substituição do perfil do aluno.

Analise a fala e a mídia, estabeleça o texto final, planeje as entradas das artes no tempo da edição e só então renderize. Não transforme a preferência por ritmo rápido de uma referência numa obrigação de cortar a cada dois segundos. Preserve inteligibilidade, respirações úteis e intenção.

Retakes exigem contexto: a última versão é uma preferência possível, não prova automática de que a anterior está errada. CTAs orgânico e anúncio devem ser entregues separados quando solicitado.

Não chame de J-cut apenas deslocar o áudio ou alinhar cortes secos. Na limpeza normal de fala, faça primeiro um **corte apertado de diálogo**: remova pausas mortas, respirações indesejadas e sobras entre takes sem cortar fonemas; a próxima fala deve entrar imediatamente após a última sílaba quando o ritmo pedir. Quando o usuário pedir J-cut, antecipe também o áudio do próximo trecho sob a imagem anterior, usando handles e faixas adequadas. O bloco de áudio pode ficar encavalado com a imagem anterior, mas duas falas inteligíveis não devem competir. Verifique pela escuta e pela forma de onda. Se o mesmo rosto permanecer com a boca visível e a antecipação criar dessincronia perceptível, use um corte apertado ou cubra a passagem com outro enquadramento, reação ou B-roll. Leia a seção de ritmo e J-cuts em `docs/DECUPAGEM-SEGURA.md`.

Uma correção vale para o projeto atual; só transforme em regra persistente do curso quando o usuário pedir. Mantenha os arquivos originais e identifique os derivados. Declare o que foi efetivamente testado, especialmente transparência, áudio e importação no editor.

## Edição e desempenho

Antes de renderizar cenas complexas, leia `edition.json` e `docs/EDICOES-E-DESEMPENHO.md` na raiz do kit. Use uma amostra curta com um render por vez e registre o resultado; não considere inventário de hardware um benchmark. Preserve a edição e os projetos anteriores ao atualizar.

Na edição Ampliada, consulte `reference-library/README.md` e filtre `reference-library/catalog.json` antes de abrir referências. O catálogo é inspiração para adaptação, não uma biblioteca já validada no motor.
